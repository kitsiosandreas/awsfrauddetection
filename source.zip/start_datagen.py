import boto3, os, sys

region   = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
cluster  = os.environ.get("ECS_CLUSTER", "fraud-demo-datagen")
task_def = os.environ.get("ECS_TASK_DEF", "fraud-demo-datagen")
subnet   = os.environ.get("ECS_SUBNET", "")
sg       = os.environ.get("ECS_SG", "")

if not subnet or not sg:
    print("ECS_SUBNET or ECS_SG not set - skipping ECS launch")
    sys.exit(0)

ecs   = boto3.client("ecs", region_name=region)
tasks = ecs.list_tasks(cluster=cluster).get("taskArns", [])
for t in tasks:
    ecs.stop_task(cluster=cluster, task=t, reason="Bootstrap restart")
    print("Stopped existing task " + t)

resp = ecs.run_task(
    cluster=cluster, taskDefinition=task_def, launchType="FARGATE", count=1,
    networkConfiguration={"awsvpcConfiguration": {
        "subnets": [subnet], "securityGroups": [sg], "assignPublicIp": "ENABLED"}})

if resp.get("tasks"):
    print("Started ECS task: " + resp["tasks"][0]["taskArn"])
elif resp.get("failures"):
    print("ECS task failed: " + str(resp["failures"]))
    sys.exit(1)
