"""
kinesis_producer.py — replaces kafka_producer.py.
Uses boto3 kinesis:PutRecord with standard IAM auth.
"""
import json, os, boto3

_client = None

def _get_client():
    global _client
    if _client is None:
        _client = boto3.client("kinesis", region_name=os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))
    return _client

def build_producer(**kwargs):
    class KinesisProducer:
        def send(self, stream, key=None, value=None):
            data = json.dumps(value).encode() if not isinstance(value, bytes) else value
            _get_client().put_record(StreamName=stream, Data=data, PartitionKey=key or "default")
            return self
        def add_errback(self, fn): return self
        def flush(self): pass
        def close(self): pass
    return KinesisProducer()

def send_event(producer, stream, event, key=None, on_error=None):
    try:
        producer.send(stream, key=key or "default", value=event)
    except Exception as e:
        if on_error:
            on_error(e)
        else:
            print("Kinesis send error: " + str(e))
